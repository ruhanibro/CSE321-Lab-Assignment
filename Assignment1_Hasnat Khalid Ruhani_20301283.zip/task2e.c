#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char str[80];
    char *start, *end;
    int i, len;
    int Palindrome = 1; 

    printf("Enter a string: ");
    fgets(str, 100, stdin);

    len = strlen(str);

    if (str[len-1] == '\n') {
        str[len-1] = '\0';
        len--;
    }

    start = str;
    end = str + len - 1;

    while (start < end) {
        if (*start != *end) {
            Palindrome = 0; 
            break;
        }
        start++;
        end--;
    }


    if (Palindrome) {
        printf("Palindrome\n");
    } else {
        printf("Not Palindrome\n");
    }

    return 0;
}