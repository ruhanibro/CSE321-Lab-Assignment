#include <stdio.h>
#include <ctype.h>

int main() {
    FILE *infile, *outfile;
    char c, prev_c = ' ';
    int spaces = 0;

    infile = fopen("input.txt", "r");
    outfile = fopen("output.txt", "w");

    while ((c = fgetc(infile)) != EOF) {
        if (isspace(prev_c) && isspace(c)) {
            spaces++;
        } else {
            if (spaces == 1) {
                fputc(prev_c, outfile);
            }
            fputc(c, outfile);
            spaces = 0;
        }
        prev_c = c;
    }

    fclose(inpfile);
    fclose(outfile);

    return 0;
}