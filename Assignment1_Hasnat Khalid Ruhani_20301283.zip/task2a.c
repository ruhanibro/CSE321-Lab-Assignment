#include<stdio.h>

int main() {
    int a,b;
    char op;

    printf("Enter two numbers by space: ");
    scanf("%d %d", &a,&b);

    printf("Enter the opeartion:");
    scanf("%c",&op);

    if (a>b) {
        printf("%d-%d =%d\n",a,b,a-b);
    }
    else if (a<b) {
        printf("%d+%d =%d\n",a,b,a+b);
    }
    else {
        printf("%d*%d =%d\n",a,b,a*b);
    }
    return 0;
}