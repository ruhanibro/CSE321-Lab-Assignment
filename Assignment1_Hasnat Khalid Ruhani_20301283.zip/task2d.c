#include <stdio.h>
#include <string.h>

int main() {
    char email[80];
    printf("Enter your email address: ");
    scanf("%s", email);

  
    if (strstr(email, "@sheba.xyz") != NULL) {
        printf("Email id is UPDATED\n");
    } else {
        printf("Email id is NOT OKAY or NOT UPDATED.\nPlease contact to your office.\n");
    }

    return 0;
}